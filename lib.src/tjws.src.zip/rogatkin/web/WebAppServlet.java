/* tjws - WebAppServlet.java
 * Copyright (C) 1999-2007 Dmitriy Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 *  (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 *  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *  $Id: WebAppServlet.java,v 1.40 2007/02/08 07:13:57 rogatkin Exp $
 * Created on Dec 14, 2004
 */

package rogatkin.web;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.EventListener;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import java.util.regex.Pattern;

import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.ServletResponse;
import javax.servlet.UnavailableException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionListener;
import javax.xml.XMLConstants;
import javax.xml.namespace.NamespaceContext;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import Acme.Utils;
import Acme.Serve.Serve;

/**
 * @author dmitriy
 * 
 * 
 */
public class WebAppServlet extends HttpServlet implements ServletContext {
	public static final String DEF_DEBUG = "rogatkin.web.WebAppServlet.debug";

	public static final String WAR_NAME_AS_CONTEXTPATH = "tjws.wardeploy.warname-as-context";

	protected static final String WEBAPPCLASSLOADER = "rogatkin.web.WebAppServlet.AppClassLoader";

	List<ServletAccessDescr> servlets;

	List<FilterAccessDescriptor> filters;

	URL[] cpUrls;

	URLClassLoader ucl;

	File deployDir;

	Serve server;

	int sessionTimeout;

	// / context methods
	protected String contextName;

	protected String contextPath;

	protected Hashtable<String, Object> attributes;

	protected Hashtable<String, String> contextParameters;

	protected List<String> welcomeFiles;

	protected List<ErrorPageDescr> errorPages;

	protected List<EventListener> listeners;

	protected List<HttpSessionListener> sessionListeners;

	protected ArrayList<ServletRequestListener> requestListeners;
	
	protected ArrayList<ServletRequestAttributeListener> attributeListeners;

	protected Map<String, String> mimes;

	protected static class MappingEntry {
		String servPath;

		Pattern pathPat;

		MappingEntry(String path, String pattern) {
			servPath = path;
			pathPat = Pattern.compile(pattern);
		}

		public String toString() {
			return String.format("Mapping of %s with regexp pat %s", servPath, pathPat);
		}
	}

	protected class ServletAccessDescr implements ServletConfig {
		String className;

		String name;

		HttpServlet instance;

		// String servPath;

		// String pathPat;

		MappingEntry[] mapping;

		Map<String, String> initParams;

		String label;

		boolean loadOnStart;

		String descr;

		long timeToReactivate; // if servlet suspended

		public java.lang.String getServletName() {
			return name;
		}

		public java.util.Enumeration getInitParameterNames() {
			return new Enumeration<String>() {
				Iterator<String> i;
				{
					i = initParams.keySet().iterator();
				}

				public boolean hasMoreElements() {
					return i.hasNext();
				}

				public String nextElement() {
					return i.next();
				}
			};
		}

		public ServletContext getServletContext() {
			return WebAppServlet.this;
		}

		public String getInitParameter(java.lang.String name) {
			return initParams.get(name);
		}

		public void add(MappingEntry entry) {
			if (mapping == null)
				mapping = new MappingEntry[1];
			else { // can't use copyOf in 1.5
				MappingEntry[] copy = new MappingEntry[mapping.length + 1];
				System.arraycopy(mapping, 0, copy, 0, mapping.length);
				mapping = copy;
			}
			mapping[mapping.length - 1] = entry;
		}

		int matchPath(String path) {
			if (mapping == null)
				return -1;
			for (int i = 0; i < mapping.length; i++)
				if (mapping[i].pathPat.matcher(path).matches())
					return i;
			return -1;
		}

		public String toString() {
			return "Servlet " + name + " class " + className + " path/patern " + Arrays.toString(mapping) + " init"
					+ initParams + " inst " + instance;
		}
	}

	static enum DispatchFilterType {
		FORWARD, INCLUDE, REQUEST, ERROR
	};

	protected class FilterAccessDescriptor extends ServletAccessDescr implements FilterConfig {
		String[] servletNames;

		Filter filterInstance;

		DispatchFilterType[] dispatchTypes;

		public java.lang.String getFilterName() {
			return name;
		}

		public void add(String name) {
			// note the local name shadows name as class memeber
			if (servletNames == null)
				servletNames = new String[1];
			else
				servletNames = Utils.copyOf(servletNames, servletNames.length + 1);
			servletNames[servletNames.length - 1] = name;
		}

		public void add(DispatchFilterType dispatcher) {
			if (dispatchTypes == null)
				dispatchTypes = new DispatchFilterType[1];
			else {
				DispatchFilterType[] copy = new DispatchFilterType[dispatchTypes.length + 1];
				System.arraycopy(dispatchTypes, 0, copy, 0, dispatchTypes.length);
				dispatchTypes = copy;
			}
			dispatchTypes[dispatchTypes.length - 1] = dispatcher;
		}

		int matchServlet(String servletName) {
			if (servletNames == null)
				return -1;
			for (int i = 0; i < this.servletNames.length; i++)
				if (servletNames[i].equals(servletName))
					return i;
			return -1;
		}

		boolean matchDispatcher(DispatchFilterType dispatcher) {
			if (dispatchTypes == null)
				if (dispatcher.equals(DispatchFilterType.REQUEST))
					return true;
				else
					return false;
			for (int i = 0; i < dispatchTypes.length; i++)
				if (dispatcher.equals(dispatchTypes[i]))
					return true;
			return false;
		}

		public String toString() {
			return String.format("Filter for servlets %s and types %s based on %s", Arrays.toString(servletNames),
					Arrays.toString(dispatchTypes), super.toString());
		}
	}

	protected static class ErrorPageDescr {
		String errorPage;

		Class exception;

		int errorCode;

		ErrorPageDescr(String page, String exClass, String code) {
			if (page == null || page.length() == 0 || page.charAt(0) != '/')
				throw new IllegalArgumentException("Error page path '" + page + "' must start with '/'");
			if (page.charAt(0) == '/')
				errorPage = page;
			else
				errorPage = "/" + page;
			try {
				exception = Class.forName(exClass);
			} catch (Exception e) {

			}
			try {
				errorCode = Integer.parseInt(code);
			} catch (Exception e) {

			}
		}
	}

	protected WebAppServlet(String context) {
		this.contextPath = "/" + context;
		attributes = new Hashtable<String, Object>();
		contextParameters = new Hashtable<String, String>();
		// TODO consider
		// _DEBUG = System.getProperty(getClass().getName() + ".debug") != null;
	}

	public static WebAppServlet create(File deployDir, String context, Serve server) throws ServletException {
		XPath xp = XPathFactory.newInstance().newXPath();
		WebAppServlet result = new WebAppServlet(context);
		result.server = server;
		try {
			result.makeCP(deployDir); // /web-app
			Node document = (Node) xp.evaluate("/*", new InputSource(new FileInputStream(new File(deployDir,
					"WEB-INF/web.xml"))), XPathConstants.NODE);
			final String namespaceURI = document.getNamespaceURI();
			String prefix = namespaceURI == null ? "" : "j2ee:";
			xp.setNamespaceContext(new NamespaceContext() {
				public String getNamespaceURI(String prefix) {
					// System.err.printf("Resolver called with %s%n", prefix);
					if (prefix == null)
						throw new IllegalArgumentException("Prefix is null.");
					if (namespaceURI == null)
						return XMLConstants.NULL_NS_URI;
					if (prefix.equals(XMLConstants.DEFAULT_NS_PREFIX))
						return namespaceURI;
					if ("j2ee".equals(prefix))
						return namespaceURI;
					return XMLConstants.NULL_NS_URI;
				}

				public String getPrefix(String arg0) {
					throw new UnsupportedOperationException("getPrefix(" + arg0 + ");");
				}

				public Iterator getPrefixes(String arg0) {
					throw new UnsupportedOperationException("getPrefixes(" + arg0 + ");");
				}
			});
			document = (Node) xp.evaluate("//" + prefix + "web-app", document, XPathConstants.NODE);
			if ("yes".equals(System.getProperty(WAR_NAME_AS_CONTEXTPATH)) == false)
				result.contextName = (String) xp.evaluate(prefix + "display-name", document, XPathConstants.STRING);
			if (result.contextName == null || result.contextName.length() == 0)
				result.contextName = context;
			else
				result.contextPath = "/" + result.contextName;
			// context parameters
			NodeList nodes = (NodeList) xp.evaluate(prefix + "context-param", document, XPathConstants.NODESET);
			int nodesLen = nodes.getLength();
			for (int p = 0; p < nodesLen; p++) {
				result.contextParameters.put((String) xp.evaluate(prefix + "param-name", nodes.item(p),
						XPathConstants.STRING), (String) xp.evaluate(prefix + "param-value", nodes.item(p),
						XPathConstants.STRING));
			}
			// session-config <session-timeout>
			Number num = (Number) xp.evaluate(prefix + "session-config/" + prefix + "session-timeout", document,
					XPathConstants.NUMBER);
			if (num != null)
				result.sessionTimeout = num.intValue();
			if (result.sessionTimeout < 0)
				result.sessionTimeout = 0;
			else
				result.sessionTimeout *= 60;
			Thread.currentThread().setContextClassLoader(result.ucl);
			// listeners listener-class
			nodes = (NodeList) xp.evaluate(prefix + "listener/" + prefix + "listener-class", document,
					XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			if (nodesLen > 0) {
				result.listeners = new ArrayList<EventListener>(nodesLen);
				for (int i = 0; i < nodesLen; i++)
					try {
						EventListener eventListener = (EventListener) result.ucl.loadClass(
								nodes.item(i).getTextContent().trim()).newInstance();
						if (eventListener instanceof HttpSessionListener) {
							if (result.sessionListeners == null)
								result.sessionListeners = new ArrayList<HttpSessionListener>(nodesLen);
							result.sessionListeners.add((HttpSessionListener) eventListener);
						}
						if (eventListener instanceof ServletRequestListener) {
							if (result.requestListeners == null)
								result.requestListeners = new ArrayList<ServletRequestListener>(nodesLen);
							result.requestListeners.add((ServletRequestListener) eventListener);
						}
						if (eventListener instanceof ServletRequestAttributeListener) {
							if (result.attributeListeners == null)
								result.attributeListeners = new ArrayList<ServletRequestAttributeListener>(nodesLen);
							result.attributeListeners.add((ServletRequestAttributeListener) eventListener);
						}
						result.listeners.add(eventListener); // because the same class can implement other listener interfaces
					} catch (Exception e) {
						result.log("Event listener " + nodes.item(i).getTextContent() + " can't be created.", e);
					} catch (Error e) {
						result.log("Event listener " + nodes.item(i).getTextContent() + " can't be created.", e);
					}
			}

			// restore sessions for this context
			// serve.sessions.restore for the current context

			// notify context listeners
			if (result.listeners != null)
				for (EventListener listener : result.listeners) {
					if (listener instanceof ServletContextListener)
						try {
							((ServletContextListener) listener).contextInitialized(new ServletContextEvent(result));
						} catch (Exception e) {
							throw new ServletException("A problem in a context listener initialization.", e);
						}
				}
			// process filters
			nodes = (NodeList) xp.evaluate(prefix + "filter", document, XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			result.filters = new ArrayList<FilterAccessDescriptor>(nodesLen);
			for (int i = 0; i < nodesLen; i++) {
				Node n = nodes.item(i);
				FilterAccessDescriptor fad = result.createFilterDescriptor();
				fad.name = (String) xp.evaluate(prefix + "filter-name", n, XPathConstants.STRING);
				fad.className = (String) xp.evaluate(prefix + "filter-class", n, XPathConstants.STRING);
				if (fad.className == null)
					throw new ServletException(String.format("Filter %s specified without or empty class.", fad.name));
				else
					fad.className = fad.className.trim();
				fad.label = (String) xp.evaluate(prefix + "display-name", n, XPathConstants.STRING);
				fad.descr = (String) xp.evaluate(prefix + "description", n, XPathConstants.STRING);
				NodeList params = (NodeList) xp.evaluate(prefix + "init-param", n, XPathConstants.NODESET);
				fad.initParams = new HashMap<String, String>(params.getLength());
				for (int p = 0; p < params.getLength(); p++) {
					fad.initParams.put((String) xp.evaluate(prefix + "param-name", params.item(p),
							XPathConstants.STRING), (String) xp.evaluate(prefix + "param-value", params.item(p),
							XPathConstants.STRING));
				}
				result.filters.add(fad);
			}
			// process filter's mapping
			for (FilterAccessDescriptor fad : result.filters) {
				nodes = (NodeList) xp.evaluate(prefix + "filter-mapping[" + prefix + "filter-name=\"" + fad.name
						+ "\"]", document, XPathConstants.NODESET);
				nodesLen = nodes.getLength();
				if (nodesLen == 0)
					throw new ServletException(String.format("No mappings were found for filter %s", fad.name));
				for (int i = 0; i < nodesLen; i++) {
					Node n = nodes.item(i);
					NodeList clarifications = (NodeList) xp.evaluate(prefix + "url-pattern", n, XPathConstants.NODESET);
					int claLen = clarifications.getLength();
					for (int j = 0; j < claLen; j++) {
						String mapUrl = clarifications.item(j).getTextContent();
						if (mapUrl == null || mapUrl.length() == 0)
							continue;
						fad.add(new MappingEntry(clearPath(mapUrl), buildREbyPathPatt(mapUrl)));
					}
					clarifications = (NodeList) xp.evaluate(prefix + "dispatcher", n, XPathConstants.NODESET);
					claLen = clarifications.getLength();
					for (int j = 0; j < claLen; j++) {
						String filterType = clarifications.item(j).getTextContent();
						if (filterType == null || filterType.length() == 0)
							fad.add(DispatchFilterType.REQUEST);
						else
							fad.add(DispatchFilterType.valueOf(filterType));
					}
					clarifications = (NodeList) xp.evaluate(prefix + "servlet-name", n, XPathConstants.NODESET);
					claLen = clarifications.getLength();
					for (int j = 0; j < claLen; j++) {
						// adding servlet name
						fad.add(clarifications.item(j).getTextContent());
					}
				}
				result.newFilterInstance(fad);
			}
			// servlets
			nodes = (NodeList) xp.evaluate(prefix + "servlet", document, XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			result.servlets = new ArrayList<ServletAccessDescr>(nodesLen + 1); // +jsp
			for (int i = 0; i < nodesLen; i++) {
				Node n = nodes.item(i);
				ServletAccessDescr sad = result.createDescriptor();
				sad.name = (String) xp.evaluate(prefix + "servlet-name", n, XPathConstants.STRING);
				sad.className = (String) xp.evaluate(prefix + "servlet-class", n, XPathConstants.STRING);
				if (sad.className == null || sad.className.length() == 0) {
					String jspFile = (String) xp.evaluate(prefix + "jsp-file", n, XPathConstants.STRING);
					if (jspFile != null) {
						result.log(String.format("Not supported servlet option jsp-file %s for %s, ignored.", jspFile,
								sad.name));
						continue;
					} else
						throw new ServletException(String.format("Servlet %s specified without class or jsp file.",
								sad.name));
				} else
					sad.className = sad.className.trim();
				sad.label = (String) xp.evaluate(prefix + "display-name", n, XPathConstants.STRING);
				sad.descr = (String) xp.evaluate(prefix + "description", n, XPathConstants.STRING);
				String loadOnStartVal = (String) xp.evaluate(prefix + "load-on-startup", n, XPathConstants.STRING);
				sad.loadOnStart = loadOnStartVal != null && loadOnStartVal.length() > 0;
				NodeList params = (NodeList) xp.evaluate(prefix + "init-param", n, XPathConstants.NODESET);
				sad.initParams = new HashMap<String, String>(params.getLength());
				for (int p = 0; p < params.getLength(); p++) {
					sad.initParams.put((String) xp.evaluate(prefix + "param-name", params.item(p),
							XPathConstants.STRING), (String) xp.evaluate(prefix + "param-value", params.item(p),
							XPathConstants.STRING));
				}
				result.servlets.add(sad);
			}
			// get mappings
			ServletAccessDescr wasDefault = null;
			for (ServletAccessDescr sad : result.servlets) {
				nodes = (NodeList) xp.evaluate(prefix + "servlet-mapping[" + prefix + "servlet-name=\"" + sad.name
						+ "\"]", document, XPathConstants.NODESET);
				nodesLen = nodes.getLength();
				// System.err.printf("Found %d mappings for %s%n", nodesLen, sad);
				if (nodesLen == 0) {
					// no mapping at all
					String urlPat = "/" + sad.name + "/*";
					sad.add(new MappingEntry(clearPath(urlPat), buildREbyPathPatt(urlPat)));
				} else
					for (int i = 0; i < nodesLen; i++) {
						NodeList maps = (NodeList) xp.evaluate(prefix + "url-pattern", nodes.item(i),
								XPathConstants.NODESET);
						int mapsLen = maps.getLength();
						// System.err.printf("Found %d patterns for %s%n", mapsLen, sad);
						if (mapsLen == 0) {
							// mapping with empty pattern
							String urlPat = "/" + sad.name + "/*";
							sad.add(new MappingEntry(clearPath(urlPat), buildREbyPathPatt(urlPat)));
						} else {
							for (int j = 0; j < mapsLen; j++) {
								String urlPat = maps.item(j).getTextContent();
								if (urlPat.equals("/"))
									if (wasDefault != null)
										throw new ServletException("More than one default servlets defined " + sad);
									else
										wasDefault = sad;
								sad.add(new MappingEntry(clearPath(urlPat), buildREbyPathPatt(urlPat)));
							}
						}
					}
				// System.err.printf("Servlet %s, path:%s\n", sad, sad.servPath);
				if (sad.loadOnStart)
					result.newInstance(sad);
			}
			// additional jsp mapping
			nodes = (NodeList) xp.evaluate(prefix + "jsp-config/" + prefix + "jsp-property-group/" + prefix
					+ "url-pattern", document, XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			if (nodesLen > 0) {
				List<String> jspPats = new ArrayList<String>(nodesLen);
				for (int i = 0; i < nodesLen; i++) {
					jspPats.add(nodes.item(i).getTextContent());
				}
				result.addJSPServlet(jspPats);
			} else
				result.addJSPServlet(null);
			if (wasDefault != null) {
				// re-add at the end
				result.servlets.remove(wasDefault);
				result.servlets.add(wasDefault);
			}
			// welcome files
			nodes = (NodeList) xp.evaluate(prefix + "welcome-file-list/" + prefix + "welcome-file", document,
					XPathConstants.NODESET);
			result.welcomeFiles = new ArrayList<String>(nodes.getLength() + 1);
			nodesLen = nodes.getLength();
			if (nodesLen > 0)
				for (int wfi = 0; wfi < nodesLen; wfi++)
					result.welcomeFiles.add(nodes.item(wfi).getTextContent());
			else {
				result.welcomeFiles.add("index.html");
				result.welcomeFiles.add("index.jsp");
			}
			// error pages
			nodes = (NodeList) xp.evaluate(prefix + "error-page", document, XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			if (nodesLen > 0) {
				result.errorPages = new ArrayList<ErrorPageDescr>(nodesLen);
				for (int i = 0; i < nodesLen; i++) {
					Node n = nodes.item(i);
					result.errorPages.add(new WebAppServlet.ErrorPageDescr((String) xp.evaluate(prefix + "location", n,
							XPathConstants.STRING), (String) xp.evaluate(prefix + "exception-type", n,
							XPathConstants.STRING), (String) xp.evaluate(prefix + "error-code", n,
							XPathConstants.STRING)));
				}
			}
			// mime types
			nodes = (NodeList) xp.evaluate(prefix + "mime-mapping", document, XPathConstants.NODESET);
			nodesLen = nodes.getLength();
			if (nodesLen > 0) {
				result.mimes = new HashMap<String, String>(nodesLen);
				for (int i = 0; i < nodesLen; i++) {
					Node n = nodes.item(i);
					result.mimes.put(((String) xp.evaluate(prefix + "extension", n, XPathConstants.STRING))
							.toLowerCase(), (String) xp.evaluate(prefix + "mime-type", n, XPathConstants.STRING));
				}
			}
		} catch (IOException ioe) {
			throw new ServletException("A problem in reading web.xml.", ioe);
		} catch (XPathExpressionException xpe) {
			xpe.printStackTrace();
			throw new ServletException("A problem in parsing web.xml.", xpe);
		} // finally { // streams will be closed by InputSource
		return result;
	}

	static <D extends ServletAccessDescr> void addMultiple(NodeList list, D d) {
		// TODO can be solution for more compact code
	}

	static public String buildREbyPathPatt(String pathPat) {
		if (pathPat.equals("/"))
			return "/.*";
		if (pathPat.startsWith("*."))
			return pathPat.replace(".", "\\.").replace("?", ".").replace("*", ".*").replace("|", "\\|"); // +"\\??.*";
		// TODO think more
		int wcp = pathPat.indexOf('*');
		if (wcp > 0 && pathPat.charAt(wcp - 1) == '/')
			pathPat = pathPat.substring(0, wcp - 1) + '*';
		pathPat = pathPat.replace(".", "\\.").replace("?", ".").replace("*", ".*");
		if (wcp < 0)
			if (pathPat.endsWith("/") == false)
				pathPat += "/?";
		return pathPat;
	}

	static public String clearPath(String pathMask) {
		if (pathMask.equals("/"))
			return pathMask;
		if (pathMask.startsWith("*."))
			return "/";
		int wcp = pathMask.indexOf('*');
		if (wcp < 0)
			return pathMask;
		return pathMask.substring(0, wcp);
	}

	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// new Exception("call trace").printStackTrace();
		// TODO check access rights
		Thread.currentThread().setContextClassLoader(ucl);
		if (req.isSecure())
			fillSecureAttrs(req);
		final HttpServletRequest hreq = (HttpServletRequest) req;
		if (this.requestListeners != null) {
			ServletRequestEvent e = new ServletRequestEvent(this, hreq);
			for (ServletRequestListener rlistener : requestListeners)
				rlistener.requestInitialized(e);
		}
		try {
			String path = hreq.getPathInfo();
			// TODO: wrap request to implement methods like getRequestDispatcher()
			// which supports relative path, no leading / means relative to currently called
			if (_DEBUG)
				System.err.printf("Full req:%s, ContextPath: %s, ServletPath:%s, pathInfo:%s\n", hreq.getRequestURI(),
						hreq.getContextPath(), hreq.getServletPath(), path);
			SimpleFilterChain sfc = new SimpleFilterChain();
			if (path != null) {
				// note a limitation, servlet name can't start with /WEB-INF
				if (path.regionMatches(true, 0, "/WEB-INF", 0, "/WEB-INF".length())) {
					((HttpServletResponse) res).sendError(HttpServletResponse.SC_FORBIDDEN);
					return;
				}
				for (FilterAccessDescriptor fad : filters)
					if (fad.matchDispatcher(DispatchFilterType.REQUEST) && fad.matchPath(path) >= 0)
						sfc.add(fad);
				for (ServletAccessDescr sad : servlets) {
					if (_DEBUG)
						System.err.println("Trying match " + path + " to " + Arrays.toString(sad.mapping) + " = "
								+ sad.matchPath(path));
					int patIndex;
					if ((patIndex = sad.matchPath(path)) >= 0) {
						if (sad.instance == null) {
							if (sad.loadOnStart == false)
								synchronized (sad) {
									if (sad.instance == null)
										newInstance(sad);
								}
							if (sad.instance == null) {
								sad.loadOnStart |= true; // mark unsuccessful instantiation and ban the servlet?
								((HttpServletResponse) res).sendError(HttpServletResponse.SC_GONE, "Servlet "
										+ sad.name + " hasn't been instantiated successfully or has been unloaded.");
								return;
							}
						} else {
							if (sad.timeToReactivate > 0) {
								if (sad.timeToReactivate > System.currentTimeMillis()) {
									((HttpServletResponse) res).setIntHeader("Retry-After",
											(int) (sad.timeToReactivate - System.currentTimeMillis()) / 1000 + 1);
									//((HttpServletResponse) res).setDateHeader("Retry-After", new Date(sad.timeToReactivate));
									((HttpServletResponse) res).sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE);
									return;
								} else
									sad.timeToReactivate = 0;
							}
						}
						for (FilterAccessDescriptor fad : filters)
							if (fad.matchDispatcher(DispatchFilterType.REQUEST) && fad.matchServlet(sad.name) >= 0)
								sfc.add(fad);
						// sfc.add(fad.filterInstance);
						// System.err.println("used:"+ sad.servPath+", wanted:"+((WebAppServlet) sad.getServletContext()).contextPath);
						sfc.setFilter(new WebAppContextFilter(sad.mapping[patIndex].servPath));
						// add servlet in chain
						sfc.setServlet(sad);
						sfc.reset();
						sfc.doFilter(req, res);
						return;
					}
				}
			} else {
				((HttpServletResponse) res).sendRedirect(hreq.getRequestURI() + "/");
				return;
			}

			// no matching, process as file
			sfc.setFilter(new WebAppContextFilter());
			sfc.setServlet(new HttpServlet() {
				public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
					String path = ((HttpServletRequest) req).getPathTranslated();
					returnFileContent(path, (HttpServletRequest) req, (HttpServletResponse) res);
				}
			});
			sfc.reset();
			sfc.doFilter(req, res);
		} finally {
			if (this.requestListeners != null) {
				ServletRequestEvent e = new ServletRequestEvent(this, hreq);
				for (ServletRequestListener rlistener : requestListeners)
					rlistener.requestDestroyed(e);
			}
		}
	}

	protected void fillSecureAttrs(ServletRequest req) {
		if (req instanceof Acme.Serve.Serve.ServeConnection) {

			if (((Serve.ServeConnection) req).getSocket() instanceof SSLSocket) {
				SSLSocket ssocket = (SSLSocket) ((Serve.ServeConnection) req).getSocket();
				SSLSession ssess = ssocket.getSession();
				String cipherSuite = ssess.getCipherSuite();

				req.setAttribute("javax.servlet.request.cipher_suite", cipherSuite);
				int cipherBits = 0;
				// TODO cache in session
				if (cipherSuite.indexOf("128") > 0)
					cipherBits = 128;
				else if (cipherSuite.indexOf("40") > 0)
					cipherBits = 40;
				else if (cipherSuite.indexOf("3DES") > 0)
					cipherBits = 168;
				else if (cipherSuite.indexOf("IDEA") > 0)
					cipherBits = 128;
				else if (cipherSuite.indexOf("DES") > 0)
					cipherBits = 56;
				req.setAttribute("javax.servlet.request.key_size", cipherBits);
				try {
					req.setAttribute("javax.servlet.request.X509Certificate", ssess.getPeerCertificateChain());
				} catch (SSLPeerUnverifiedException e) {
				}
			}

		}
	}

	protected SimpleFilterChain buildFilterChain(String servletName, String requestPath, DispatchFilterType filterType) {
		SimpleFilterChain sfc = new SimpleFilterChain();
		// add path filters
		if (requestPath != null)
			for (FilterAccessDescriptor fad : filters)
				if (fad.matchDispatcher(filterType) && fad.matchPath(requestPath) >= 0)
					sfc.add(fad);
		// add name filters
		if (servletName != null)
			for (FilterAccessDescriptor fad : filters)
				if (fad.matchDispatcher(DispatchFilterType.REQUEST) && fad.matchServlet(servletName) >= 0)
					sfc.add(fad);
		return sfc;
	}

	protected void returnFileContent(String path, HttpServletRequest req, HttpServletResponse res) throws IOException,
			ServletException {
		File fpath = new File(path);
		if (fpath.isDirectory()) {
			File baseDir = fpath;
			for (String indexPage : welcomeFiles) {
				fpath = new File(baseDir, indexPage);
				if (fpath.exists() && fpath.isFile()) {
					if (indexPage.charAt(0) != '/')
						indexPage = "/" + indexPage;
					RequestDispatcher rd = req.getRequestDispatcher(indexPage);
					if (rd != null) {
						rd.forward(req, res);
						return;
					}
					break;
				}
			}
		}
		if (fpath.exists() == false) {
			res.sendError(res.SC_NOT_FOUND);
			return;
		}
		if (fpath.isFile() == false) {
			res.sendError(res.SC_FORBIDDEN);
			return;
		}

		res.setContentType(getServletContext().getMimeType(fpath.getName()));
		res.setHeader("Content-Length", Long.toString(fpath.length()));
		res.setContentType(getMimeType(fpath.getName()));
		long lastMod = fpath.lastModified();
		res.setDateHeader("Last-modified", lastMod);
		String ifModSinceStr = req.getHeader("If-Modified-Since");
		long ifModSince = -1;
		if (ifModSinceStr != null) {
			int semi = ifModSinceStr.indexOf(';');
			if (semi != -1)
				ifModSinceStr = ifModSinceStr.substring(0, semi);
			try {
				ifModSince = DateFormat.getDateInstance().parse(ifModSinceStr).getTime();
			} catch (Exception ignore) {
			}
		}
		if (ifModSince != -1 && ifModSince >= lastMod) {
			res.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
			return;
		}
		if ("HEAD".equals(req.getMethod()))
			return;
		OutputStream os = null;
		InputStream is = null;
		try {
			is = new FileInputStream(fpath);
			os = res.getOutputStream();
			WarRoller.copyStream(is, os);
		} catch (IllegalStateException ise) {
			PrintWriter pw = res.getWriter();
			// TODO decide on encoding/charset used by the reader
			String charSetName = res.getCharacterEncoding();
			if (charSetName == null)
				charSetName = Utils.ISO_8859_1;
			Utils.copyStream(new InputStreamReader(is, charSetName), pw);
			// consider Writer is OK to do not close
			// consider underneath stream closing OK
		} finally {
			try {
				is.close();
			} catch (Exception x) {
			}
			try {
				if (os != null)
					os.close();
			} catch (Exception x) {
			}
		}

	}

	protected void addJSPServlet(List<String> patterns) {
		ServletAccessDescr sad = createDescriptor();
		// get class name from serve
		sad.initParams = new HashMap<String, String>(10);
		Map<String, String> arguments = (Map<String, String>) server.arguments;
		sad.className = arguments.get(Serve.ARG_JSP);
		if (sad.className == null) {
			sad.className = "org.gjt.jsp.JSPServlet";
			sad.initParams.put("repository", new File(deployDir, "~~~").getPath());
			sad.initParams.put("debug", System.getProperty(getClass().getName() + ".debug") != null ? "yes" : "no");
			sad.initParams.put("classloadername", WEBAPPCLASSLOADER);
		} else {
			String pnpx = sad.className + '.';
			int cnl = pnpx.length();
			String classPath = Utils.calculateClassPath(ucl);
			for (String ipn : arguments.keySet())
				if (ipn.startsWith(pnpx))
					sad.initParams.put(ipn.substring(cnl), arguments.get(ipn).replace("%context%", contextName)
							.replace("%deploydir%", deployDir.getPath()).replace("%classloader%", WEBAPPCLASSLOADER)
							.replace("%classpath%", classPath));
		}
		sad.descr = "JSP support servlet";
		sad.label = "JSP";
		sad.loadOnStart = false;
		sad.name = "jsp";
		String jspPat;
		if (patterns == null || patterns.size() == 0)
			jspPat = "/.*\\.jsp";
		else {
			jspPat = buildREbyPathPatt(patterns.get(0));
			for (int i = 1; i < patterns.size(); i++)
				jspPat += "|" + buildREbyPathPatt(patterns.get(i));
		}
		sad.add(new MappingEntry("/", jspPat));
		servlets.add(sad);
	}

	protected ServletAccessDescr createDescriptor() {
		return new ServletAccessDescr();
	}

	protected FilterAccessDescriptor createFilterDescriptor() {
		return new FilterAccessDescriptor();
	}

	protected void makeCP(File dd) throws IOException {
		deployDir = dd.getCanonicalFile();
		final List<URL> urls = new ArrayList<URL>();
		File classesFile = new File(deployDir, "WEB-INF/classes");
		if (classesFile.exists() && classesFile.isDirectory())
			try {
				urls.add(classesFile.toURL());
			} catch (java.net.MalformedURLException mfe) {

			}
		File libFile = new File(deployDir, "WEB-INF/lib");
		libFile.listFiles(new FileFilter() {
			public boolean accept(File file) {
				String name = file.getName().toLowerCase();
				if (name.endsWith(".jar") || name.endsWith(".zip"))
					try {
						urls.add(file.toURL());
					} catch (java.net.MalformedURLException mfe) {

					}
				return false;
			}
		});
		cpUrls = urls.toArray(new URL[urls.size()]);
		ucl = URLClassLoader.newInstance(cpUrls, getClass().getClassLoader());
		setAttribute(WEBAPPCLASSLOADER, ucl);
		// System.err.println("CP "+urls+"\nLoader:"+ucl);
	}

	protected HttpServlet newInstance(ServletAccessDescr descr) throws ServletException {
		try {
			// System.err.printf("new instance %s %s%n", descr.className, Arrays.toString(ucl.getURLs()));
			descr.instance = (HttpServlet) ucl.loadClass(descr.className).newInstance();
			descr.instance.init(descr);
			// TODO think about setting back context loader
		} catch (InstantiationException ie) {
			throw new ServletException("Servlet class " + descr.className + " can't instantiate. ", ie);
		} catch (IllegalAccessException iae) {
			throw new ServletException("Servlet class " + descr.className + " can't access. ", iae);
		} catch (ClassNotFoundException cnfe) {
			log("", cnfe);
			throw new ServletException("Servlet class " + descr.className + " not found. ", cnfe);
		} catch (Error e) {
			throw new ServletException("Servlet class " + descr.className
					+ " can't be instantiated or initialized due an error.", e);
		} catch (Throwable t) {
			if (t instanceof ThreadDeath)
				throw (ThreadDeath) t;
			throw new ServletException("Servlet class " + descr.className
					+ " can't be instantiated or initialized due an exception.", t);
		}
		return descr.instance;
	}

	protected Filter newFilterInstance(FilterAccessDescriptor descr) throws ServletException {
		try {
			descr.filterInstance = (Filter) ucl.loadClass(descr.className).newInstance();
			descr.filterInstance.init(descr);
		} catch (InstantiationException ie) {
			throw new ServletException("Filter class " + descr.className + " can't instantiate. ", ie);
		} catch (IllegalAccessException iae) {
			throw new ServletException("Filter class " + descr.className + " can't access. ", iae);
		} catch (ClassNotFoundException cnfe) {
			throw new ServletException("Filter class " + descr.className + " not found. ", cnfe);
		}
		return descr.filterInstance;
	}

	/*
	 * protected URL toURL(File file) throws MalformedURLException { System.err.println("file:/"+file.getAbsolutePath()+(file.isDirectory()?"/":"")); return new
	 * URL("file:/"+file.getAbsolutePath()+(file.isDirectory()?"/":"")); }
	 */

	// /////////////////////////////////////////////////////////////////////////////////
	// context methods
	public String getContextPath() {
		return contextPath;
	}

	public String getServletContextName() {
		return contextName;
	}

	public void removeAttribute(java.lang.String name) {
		Object value = attributes.remove(name);
		if (listeners != null)
			for (EventListener listener : listeners)
				if (listener instanceof ServletContextAttributeListener)
					((ServletContextAttributeListener) listener).attributeRemoved(new ServletContextAttributeEvent(
							this, name, value));
	}

	public void setAttribute(java.lang.String name, java.lang.Object object) {
		// log("Set attr:"+name+" to "+object);
		if (object == null) {
			removeAttribute(name);
			return;
		}
		Object oldObj = attributes.put(name, object);
		if (listeners != null)
			for (EventListener listener : listeners) {
				if (listener instanceof ServletContextAttributeListener)
					if (oldObj == null)
						((ServletContextAttributeListener) listener).attributeAdded(new ServletContextAttributeEvent(
								this, name, object));
					else
						((ServletContextAttributeListener) listener)
								.attributeReplaced(new ServletContextAttributeEvent(this, name, object));
			}
	}

	public java.util.Enumeration getAttributeNames() {
		return attributes.keys();
	}

	public java.lang.Object getAttribute(java.lang.String name) {
		// log("context: "+this+" return attr:"+name+" as "+attributes.get(name));
		return attributes.get(name);
	}

	public java.lang.String getServerInfo() {
		return "TJWS/J2EE container, Copyright &copy; 1998-2007 Dmitriy Rogatkin";
	}

	public java.lang.String getRealPath(java.lang.String path) {
		path = validatePath(path);
		if (path == null)
			return deployDir.toString();
		else
			return new File(deployDir, path).toString();
	}

	public void log(java.lang.String msg) {
		server.log((contextName == null ? "" : contextName) + "> " + msg);
	}

	public void log(java.lang.Exception exception, java.lang.String msg) {
		server.log(exception, (contextName == null ? "" : contextName) + "> " + msg);
	}

	public void log(java.lang.String message, java.lang.Throwable throwable) {
		server.log((contextName == null ? "" : contextName) + "> " + message, throwable);
	}

	public java.util.Enumeration getServletNames() {
		Vector<String> result = new Vector<String>();
		for (ServletAccessDescr sad : servlets)
			result.add(sad.name);
		return result.elements();
	}

	public java.util.Enumeration getServlets() {
		Vector<HttpServlet> result = new Vector<HttpServlet>();
		for (ServletAccessDescr sad : servlets)
			result.add(sad.instance);
		return result.elements();

	}

	public Servlet getServlet(java.lang.String name) throws ServletException {
		for (ServletAccessDescr sad : servlets)
			if (name.equals(sad.name))
				return sad.instance;
		throw new ServletException("No servlet " + name);
	}

	public RequestDispatcher getNamedDispatcher(java.lang.String name) {
		for (ServletAccessDescr sad : servlets)
			if (name.equals(sad.name)) {
				if (sad.instance == null && sad.loadOnStart == false)
					try {
						newInstance(sad);
					} catch (ServletException se) {
					}
				if (sad.instance != null)
					return new SimpleDispatcher(name, sad.instance);
				else
					break;
			}
		return null;
	}

	public RequestDispatcher getRequestDispatcher(java.lang.String path) {
		if (_DEBUG)
			System.err.printf("getRequestDispatcher(%s)%n", path);
		if (path == null || path.length() == 0 || path.charAt(0) != '/')
			return null; // path must start with / for call from context
		// look for servlets first
		int sp = path.indexOf('?');
		if (sp < 0)
			sp = path.indexOf('#'); // exclude possible fragment
		// if (sp < 0)
		// sp = path.indexOf(Serve.ServeConnection.SESSION_URL_NAME);
		String clearPath = sp < 0 ? path : path.substring(0, sp);
		for (ServletAccessDescr sad : servlets) {
			if (_DEBUG)
				System.err.printf("For dispatcher trying match %s (%s) %s = %b%n", path, clearPath, Arrays
						.toString(sad.mapping), sad.matchPath(clearPath));
			int patIndex;
			if ((patIndex = sad.matchPath(clearPath)) >= 0) {
				if (sad.instance == null && sad.loadOnStart == false)
					try {
						synchronized (sad) {
							if (sad.instance == null)
								newInstance(sad);
						}
					} catch (ServletException se) {
						log(String.format("Can't instantiate instance %s exception %s", sad, se));
					}
				if (sad.instance != null)
					return new SimpleDispatcher(sad.instance, sad.mapping[patIndex].servPath, path);
				else
					return null; // servlet not working
			}
		}
		// no matching servlets, check for resources
		try {
			if (_DEBUG)
				System.err.printf("Dispatching to resource %s%n", path);
			if (getResource(path) == null)
				throw new MalformedURLException(); // check path is valid
			return new SimpleDispatcher(new HttpServlet() {
				public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
					String path;
					if (((HttpServletRequest) req).getAttribute("javax.servlet.include.request_uri") != null)
						path = req.getRealPath((String) req.getAttribute("javax.servlet.include.path_info"));
					else
						path = ((HttpServletRequest) req).getPathTranslated();
					if (_DEBUG)
						System.err.printf("Dispatched file servlet for %s translated %s%n", path,
								((HttpServletRequest) req).getPathTranslated());
					returnFileContent(path, (HttpServletRequest) req, (HttpServletResponse) res);
				}
			}, path);
		} catch (MalformedURLException mfe) {
		}
		return null;
	}

	public java.io.InputStream getResourceAsStream(java.lang.String path) {
		try {
			return getResource(path).openStream();
		} catch (NullPointerException npe) {
			if (_DEBUG)
				System.err.println("URL can't be created for :" + path);
		} catch (IOException ioe) {
			if (_DEBUG)
				ioe.printStackTrace();
		}
		return null;
	}

	public java.net.URL getResource(java.lang.String path) throws java.net.MalformedURLException {
		if (path.charAt(0) != '/')
			throw new MalformedURLException("Path: " + path + " has to start with '/'");
		int pp = path.indexOf('?');
		// no check for # ?
		try {
			return new File(getRealPath((pp > 0 ? path.substring(0, pp) : path))).getCanonicalFile().toURL();
		} catch (IOException io) {
		}
		return null;
	}

	public java.util.Set getResourcePaths(java.lang.String path) {
		if (path.charAt(0) != '/')
			throw new IllegalArgumentException("getResourcePaths: path parameters must begin with '/'");
		int pp = path.indexOf('?');
		if (pp > 0)
			path = path.substring(0, pp);
		File dir = new File(getRealPath(path));
		if (dir.exists() == false || dir.isDirectory() == false)
			return null;
		Set<String> set = new TreeSet<String>();
		String[] els = dir.list();
		for (String el : els) {
			String fp = path + "/" + el;
			if (new File(getRealPath(fp)).isDirectory())
				fp += "/";
			set.add("/" + fp);
		}
		return set;
	}

	public java.lang.String getMimeType(java.lang.String file) {
		if (mimes != null && file != null) {
			int p = file.lastIndexOf('.');
			if (p > 0) {
				String result = mimes.get(file.substring(p).toLowerCase());
				if (result != null)
					return result;
			}
		}
		return server.getMimeType(file);
	}

	public int getMinorVersion() {
		return 5;
	}

	public int getMajorVersion() {
		return 2;
	}

	public ServletContext getContext(java.lang.String uripath) {
		Servlet servlet = server.getServlet(uripath);
		if (servlet != null)
			return servlet.getServletConfig().getServletContext();
		return null;
	}

	public java.lang.String getInitParameter(java.lang.String name) {
		return contextParameters.get(name);
	}

	public java.util.Enumeration getInitParameterNames() {
		return contextParameters.keys();
	}

	protected void setErrorAttributes(ServletRequest req, int status, String msg, String servletName,
			String requestURI, Throwable t, Class eclass) {
		req.setAttribute("javax.servlet.error.status_code", status);
		req.setAttribute("javax.servlet.error.exception_type ", eclass);
		req.setAttribute("javax.servlet.error.message", msg);
		req.setAttribute("javax.servlet.error.exception", t);
		req.setAttribute("javax.servlet.error.request_uri", requestURI);
		req.setAttribute("javax.servlet.error.servlet_name", servletName);
	}

	public static String validatePath(String path) {
		return Utils.canonicalizePath(path);
	}

	public void destroy() {
		Thread.currentThread().setContextClassLoader(ucl);
		if (filters != null)
			for (FilterAccessDescriptor fad : filters)
				if (fad.filterInstance != null)
					fad.filterInstance.destroy();
		for (ServletAccessDescr sad : servlets)
			if (sad.instance != null)
				sad.instance.destroy();
		if (listeners != null)
			for (int i = listeners.size() - 1; i > -1; i--) {
				EventListener listener = listeners.get(i);
				if (listener instanceof ServletContextListener)
					((ServletContextListener) listener).contextDestroyed(new ServletContextEvent(this));
			}
		Enumeration e = getAttributeNames();
		while (e.hasMoreElements())
			removeAttribute((String) e.nextElement());
		// log("Destroy");
	}

	protected class SimpleDispatcher implements RequestDispatcher {
		HttpServlet servlet;

		String servletPath;

		String path;

		String named;

		SimpleDispatcher(HttpServlet s, String p) {
			this(s, null, p);
		}

		SimpleDispatcher(String n, HttpServlet s) {
			this(s, null, null);
			named = n;
		}

		SimpleDispatcher(HttpServlet s, String sp, String p) {
			servlet = s;
			path = p;
			servletPath = sp;
			//if (servletPath.length() > 1 && servletPath.endsWith("/"))
			//	servletPath = servletPath.substring(0, servletPath.length()-1);
			// ending '/' adjustment done on demand
		}

		// //////////////////////////////////////////////////////////////////
		// interface RequestDispatcher

		public void forward(ServletRequest request, ServletResponse response) throws ServletException,
				java.io.IOException {
			if (_DEBUG)
				System.err.printf("FORWARD path: %s, servlet: %s%n", path, servlet);
			response.reset(); // drop all previously putting data and headers
			SimpleFilterChain sfc = buildFilterChain(named, path, request
					.getAttribute("javax.servlet.error.status_code") == null ? DispatchFilterType.FORWARD
					: DispatchFilterType.ERROR);
			sfc.setServlet(servlet);
			sfc.reset();
			sfc.doFilter(new DispatchedRequest((HttpServletRequest) request, true), response);
			// servlet.service(new DispatchedRequest((HttpServletRequest) request, true), response);
			if (response instanceof Serve.ServeConnection)
				((Serve.ServeConnection) response).close();
		}

		public void include(ServletRequest request, final ServletResponse response) throws ServletException,
				java.io.IOException {
			if (response instanceof Serve.ServeConnection)
				((Serve.ServeConnection) response).setInInclude(true);
			if (_DEBUG)
				System.err.printf("INCLUDE path: %s, servlet: %s, servlet path %s%n", path, servlet, servletPath);
			try {
				SimpleFilterChain sfc = buildFilterChain(named, path, DispatchFilterType.INCLUDE);
				sfc.setServlet(servlet);
				sfc.reset();
				sfc.doFilter(new DispatchedRequest((HttpServletRequest) request, false),
						new HttpServletResponseWrapper((HttpServletResponse) response) {
							public void addDateHeader(java.lang.String name, long date) {
							}

							public void setDateHeader(java.lang.String name, long date) {
							}

							public void setHeader(java.lang.String name, java.lang.String value) {
							}

							public void addHeader(java.lang.String name, java.lang.String value) {
							}

							public void setIntHeader(java.lang.String name, int value) {
							}

							public void addIntHeader(java.lang.String name, int value) {
							}

							public void setStatus(int sc) {
							}

							public void setStatus(int sc, java.lang.String sm) {
							}

							public void sendRedirect(java.lang.String location) throws java.io.IOException {
							}

							public void sendError(int sc) throws java.io.IOException {
							}

							public void sendError(int sc, java.lang.String msg) throws java.io.IOException {
							}

							public void reset() {
							}

							public void setLocale(java.util.Locale loc) {
							}

							public void resetBuffer() {
							}

							public void setContentType(java.lang.String type) {
							}

							public void setContentLength(int len) {
							}

							public void setCharacterEncoding(java.lang.String charset) {
							}
						});
			} finally {
				if (response instanceof Serve.ServeConnection)
					((Serve.ServeConnection) response).setInInclude(false);
			}
		}

		class DispatchedRequest extends HttpServletRequestWrapper {
			boolean forward;

			DispatchedRequest(HttpServletRequest request, boolean forward) {
				super(request);
				this.forward = forward;
			}

			public java.lang.String getPathInfo() {
				if (forward)
					return getPathInfo1();
				return super.getPathInfo();
			}

			public java.lang.String getPathInfo1() {
				if (path == null)
					return super.getPathInfo();
				if (path.equals("/") || "/".equals(servletPath))
					return null;
				int qp = path.indexOf('?');
				int sp = servletPath == null ? -1 : path.indexOf(servletPath);
				if (sp >= 0) {
					sp += servletPath.length() - (servletPath.endsWith("/") ? 1 : 0);
					if (_DEBUG)
						System.err.printf("FORWARD pathinfo path %s, servlet %s, sp %d, qp %d, res %s%n", path,
								servletPath, sp, qp, path.substring(sp));
					if (qp > sp)
						return path.substring(sp, qp);
					else
						return path.substring(sp);
				}
				if (_DEBUG)
					System.err.printf("FORWARD pathinfo %s%n", path);
				return path;
			}

			public java.lang.String getPathTranslated() {
				return getRealPath(getPathInfo());
			}

			public java.lang.String getRealPath(java.lang.String path) {
				return WebAppServlet.this.getRealPath(path);
			}

			public String getServletPath() {
				if (forward)
					return getServletPath1();
				return super.getServletPath();
			}

			public String getServletPath1() {
				if (servletPath != null)
					if (servletPath.equals("/"))
						return path;
					else
						return servletPath.endsWith("/") ? servletPath.substring(0, servletPath.length() - 1)
								: servletPath;
				return super.getServletPath();
			}

			public String getRequestURI1() {
				if (path == null)
					if (servletPath != null)
						return servletPath;
					else
						return null;
				int qp = path.indexOf('?');
				if (qp > 0)
					return path.substring(0, qp);
				return path;
			}

			public String getRequestURI() {
				if (forward)
					return getRequestURI1();
				return super.getRequestURI();
			}

			public String getContextPath() {
				return contextPath;
			}

			public String getQueryString1() {
				if (path == null)
					return null;
				int qp = path.indexOf('?');
				if (qp > 0 && qp < path.length() - 1)
					return path.substring(qp + 1);
				return null;
			}

			public String getQueryString() {
				if (forward)
					return getQueryString1();
				return super.getQueryString();
			}

			public java.util.Enumeration getAttributeNames() {
				List<String> attributes = new ArrayList<String>(10);
				if (named == null) {
					if (forward) {
						attributes.add("javax.servlet.forward.request_uri");
						attributes.add("javax.servlet.forward.context_path");
						attributes.add("javax.servlet.forward.servlet_path");
						attributes.add("javax.servlet.forward.path_info");
						attributes.add("javax.servlet.forward.query_string");
					} else {
						attributes.add("javax.servlet.include.request_uri");
						attributes.add("javax.servlet.include.path_info");
						attributes.add("javax.servlet.include.context_path");
						attributes.add("javax.servlet.include.servlet_path");
						attributes.add("javax.servlet.include.query_string");
					}
				}
				Enumeration e = super.getAttributeNames();
				while (e.hasMoreElements())
					attributes.add((String) e.nextElement());
				return Collections.enumeration(attributes);
			}

			public Object getAttribute(String name) {
				if (named == null) {
					if (forward) {
						if ("javax.servlet.forward.request_uri".equals(name))
							return super.getRequestURI();
						else if ("javax.servlet.forward.context_path".equals(name))
							return super.getContextPath();
						else if ("javax.servlet.forward.servlet_path".equals(name))
							return super.getServletPath();
						else if ("javax.servlet.forward.path_info".equals(name))
							return super.getPathInfo();
						else if ("javax.servlet.forward.query_string".equals(name))
							return super.getQueryString();
					} else {
						if ("javax.servlet.include.request_uri".equals(name))
							return getRequestURI1();
						else if ("javax.servlet.include.path_info".equals(name))
							return getPathInfo1();
						else if ("javax.servlet.include.context_path".equals(name))
							return getContextPath();
						else if ("javax.servlet.include.query_string".equals(name))
							return getQueryString1();
						else if ("javax.servlet.include.servlet_path".equals(name))
							return getServletPath1();
					}
				}
				// System.err.printf("!!!return attr:%s=%s%n", name, super.getAttribute(name));
				return super.getAttribute(name);
			}

			// @Override
			// public void setAttribute(String name, Object value) {
			//    System.err.printf("!!!Set attr %s=%s%n", name, value);
			//    super.setAttribute(name, value);
			// }

			@Override
			public RequestDispatcher getRequestDispatcher(String path) {
				if (path.charAt(0) != '/')
					path = getServletPath() + '/' + path;
				return WebAppServlet.this.getRequestDispatcher(path);
			}

			public String getParameter(String name) {
				Map<String, String[]> params = createParameters();
				String[] result = params.get(name);
				if (result != null)
					return result[0];
				return super.getParameter(name);
			}

			public Map getParameterMap() {
				Map result = super.getParameterMap();
				result.putAll(createParameters());
				return result;
			}

			public Enumeration getParameterNames() {
				Map params = getParameterMap();
				Hashtable result = new Hashtable();
				result.putAll(params);
				return result.keys();
			}

			public String[] getParameterValues(String name) {
				Map<String, String[]> params = createParameters();
				String[] result = params.get(name);
				if (result != null)
					return result;
				return super.getParameterValues(name);
			}

			protected Map<String, String[]> createParameters() {
				String query = getQueryString();
				if (query != null)
					return Acme.Utils.parseQueryString(query, null);
				return new Hashtable<String, String[]>();
			}
		}
	}

	// ////////////// Filter methods /////////////////////
	protected class WebAppContextFilter implements Filter {
		String servPathHolder;

		WebAppContextFilter(String servletPath) {
			if (servletPath != null)
				servPathHolder = servletPath;
			else
				throw new NullPointerException("Servlet path is null");
		}

		WebAppContextFilter() {
			this("/");
		}

		public void init(FilterConfig filterConfig) throws ServletException {
		}

		public void doFilter(final ServletRequest request, ServletResponse response, FilterChain chain)
				throws java.io.IOException, ServletException {
			final HttpServletRequest hreq = (HttpServletRequest) request;
			final HttpServletResponse hres = (HttpServletResponse) response;
			chain.doFilter((HttpServletRequest) Proxy.newProxyInstance(javax.servlet.http.HttpServletRequest.class
					.getClassLoader(), new Class[] { javax.servlet.http.HttpServletRequest.class },
					new InvocationHandler() {
						public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
							String mn = method.getName();
							if (mn.equals("getServletPath")) {
								if (_DEBUG)
									System.err.println("getServletPath() "
											+ extractPath(hreq.getRequestURI(), contextPath, servPathHolder, false));
								return extractPath(hreq.getRequestURI(), contextPath, servPathHolder, false);
							} else if (mn.equals("getPathInfo")) {
								if (_DEBUG)
									System.err.println("getPathInfo() "
											+ extractPath(hreq.getRequestURI(), contextPath, servPathHolder, true));
								return extractPath(hreq.getRequestURI(), contextPath, servPathHolder, true);
							} else if (mn.equals("getRealPath")) {
								if (_DEBUG)
									System.err.println("Path:" + args[0]);
								return getRealPath((String) args[0]);
							} else if (mn.equals("getPathTranslated")) {
								return getRealPath(hreq.getPathInfo());
							} else if (mn.equals("getRequestDispatcher")) {
								String url = (String) args[0];
								if (url.charAt(0) != '/')
									url = extractPath(hreq.getRequestURI(), contextPath, servPathHolder, false) + '/'
											+ url;
								// System.err.printf("req.getDispatcher(%s), %s%n", url, extractPath(hreq.getRequestURI(), contextPath, servPathHolder, false));
								return getRequestDispatcher(url);
							} else if (mn.equals("getContextPath")) {
								return contextPath;
							} else if (mn.equals("getSession")) {
								// System.err.println("getsession");
								HttpSession session = (HttpSession) method.invoke(hreq, args);
								// TODO some overhead is here, context and listeners will be overloaded each time
								// time of accessing session while it's new
								if (session instanceof Serve.AcmeSession
										&& (session.getServletContext() == null || session.isNew())) {
									// System.err.println("set listeners & context");
									((Serve.AcmeSession) session).setListeners(WebAppServlet.this.sessionListeners);
									((Serve.AcmeSession) session).setServletContext(WebAppServlet.this);
									if (sessionTimeout > 0)
										session.setMaxInactiveInterval(sessionTimeout);
								}
								return session;
							} else  if (attributeListeners != null){
								if (mn.equals("setAttribute")) {
									Object av = hreq.getAttribute((String)args[0]);
									hreq.setAttribute((String)args[0], args[1]);
									if (av == null) {
										ServletRequestAttributeEvent e = new ServletRequestAttributeEvent(WebAppServlet.this, hreq, (String)args[0], args[1]);
										for (ServletRequestAttributeListener sarl: attributeListeners )
											sarl.attributeAdded(e);
									} else {
										ServletRequestAttributeEvent e = new ServletRequestAttributeEvent(WebAppServlet.this, hreq, (String)args[0], av);
										for (ServletRequestAttributeListener sarl: attributeListeners )
											sarl.attributeReplaced(e);
									}
									return null;
								} else if (mn.equals("removeAttribute")) {
									Object av = hreq.getAttribute((String)args[0]);
									hreq.removeAttribute((String)args[0]);
									ServletRequestAttributeEvent e = new ServletRequestAttributeEvent(WebAppServlet.this, hreq, (String)args[0], av);
									for (ServletRequestAttributeListener sarl: attributeListeners )
										sarl.attributeRemoved(e);
									return null;
								}
							}
							try {
								return method.invoke(hreq, args);
							} catch (InvocationTargetException ite) {
								throw ite.getTargetException();
							}
						}
					}), // response);
					(HttpServletResponse) Proxy.newProxyInstance(javax.servlet.http.HttpServletResponse.class
							.getClassLoader(), new Class[] { javax.servlet.http.HttpServletResponse.class },
							new InvocationHandler() {
								public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
									String mn = method.getName();
									if (mn.equals("sendError")) {
										if (errorPages != null)
											for (ErrorPageDescr epd : errorPages)
												if (epd.errorCode == ((Integer) args[0]).intValue()) {
													setErrorAttributes(hreq, (Integer) args[0],
															args.length > 1 ? (String) args[1] : "", getServletName(),
															hreq.getRequestURI(), null, null);
													// System.err.printf("Forwarding to %s for %d%n",epd.errorPage, args[0]);
													getRequestDispatcher(epd.errorPage).forward(hreq, hres);
													return null;
												}
									} // else if (mn.equals("sendRedirect")) {
									// System.err.printf("Redirect to:%s%n",args[0]);
									// }
									return method.invoke(hres, args);
								}
							}));
		}

		public void destroy() {
			// destroy context filter
		}
	}

	static public String extractPath(String uri, String context, String servlet, boolean info) {
		if (_DEBUG)
			System.err.printf("Extract path URI: %s, context: %s, servlet: %s, action %b\n", uri, context, servlet,
					info);
		int sp = uri.indexOf(servlet, context.length());
		if (sp < 0) {
			sp = context.length();
			/*
			 * if (_DEBUG) System.err.printf("servlet pos: -1 %n"); if (info) return null; // invalid URI or too short return uri.substring(context.length());
			 */
		}
		int pp = uri.indexOf('?', sp);
		int ip = servlet.endsWith("/") ? sp + servlet.length() - 1 : uri.indexOf('/', sp + servlet.length());
		if (_DEBUG)
			System.err.printf("servlet pos %d, info pos: %d, param pos: %d %n", sp, ip, pp);
		if (info == false) {
			if (servlet.equals("/") || ip < 0)
				if (pp > 0)
					return uri.substring(sp, pp);
				else
					return uri.substring(sp);
			if (pp < 0)
				return uri.substring(sp, ip);

			return uri.substring(sp, pp);
		}
		if (servlet.equals("/") || ip < 0 || (pp > 0 && ip > pp))
			return null;
		if (pp < 0)
			return uri.substring(ip);
		return uri.substring(ip, pp);
	}

	protected class SimpleFilterChain implements FilterChain {
		List<FilterAccessDescriptor> filters;

		Iterator<FilterAccessDescriptor> iterator;

		HttpServlet servlet;

		Filter filter;

		Filter nextFilter;

		ServletAccessDescr sad;

		SimpleFilterChain() {
			filters = new ArrayList<FilterAccessDescriptor>();
		}

		public void setFilter(Filter filter) {
			this.filter = filter;
		}

		public void doFilter(ServletRequest request, ServletResponse response) throws java.io.IOException,
				ServletException {

			if (nextFilter != null) {
				nextFilter = null;
				filter.doFilter(request, response, this);
			} else if (iterator.hasNext()) {
				FilterAccessDescriptor fad = iterator.next();
				try {
					fad.filterInstance.doFilter(request, response, this);
				} catch (UnavailableException ue) {
					if (ue.isPermanent()) {
						synchronized (fad) {
							if (fad.filterInstance != null) {
								fad.filterInstance.destroy();
								fad.filterInstance = null;
							}
						}
					} else {
						fad.timeToReactivate = System.currentTimeMillis() + ue.getUnavailableSeconds() * 1000l;
					}
					doFilter(request, response);
					// iterator.remove();
				}
			} else
				// TODO figure out error handler needed for filters, it should also handle UnavailableException
				// call sevlet
				try {
					servlet.service(request, response);
				} catch (IOException ioe) {
					if (handleError(ioe, request, response) == false)
						throw ioe;
				} catch (UnavailableException ue) {
					// log("Servlet " + servlet + " asked to be unavailable", ue);
					if (sad != null) {
						if (ue.isPermanent()) {
							synchronized (sad) {
								if (sad.instance != null) {
									sad.instance.destroy();
									sad.instance = null;
								}
							}
						} else {
							sad.timeToReactivate = System.currentTimeMillis() + ue.getUnavailableSeconds() * 1000l;
						}
					}
					((HttpServletResponse) response).sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE, ue
							.getMessage());
					// allowing custom handling?
					// eating an exception to avoid removing entire webapp servlet throw ue;
				} catch (ServletException se) {
					if (handleError(se, request, response) == false)
						throw se;
				} catch (Throwable re) {
					if (handleError(re, request, response) == false)
						throw new RuntimeException(re);
				}
		}

		protected boolean handleError(Throwable t, ServletRequest request, ServletResponse response)
				throws java.io.IOException, ServletException {
			if (errorPages != null) {
				Class eclass = t.getClass();
				for (ErrorPageDescr epd : errorPages) {
					if (epd.exception != null && eclass.equals(epd.exception)) {
						log("forward to " + epd.errorPage, t);
						((HttpServletResponse) response).sendRedirect(epd.errorPage);
						setErrorAttributes(request, -1, t.getMessage(), getServletName(),
								((HttpServletRequest) request).getRequestURI(), t, t.getClass());
						getRequestDispatcher(epd.errorPage).forward(request, response);
						return true;
					}
				}
				Class[] peclasses = eclass.getClasses();
				for (Class peclass : peclasses)
					for (ErrorPageDescr epd : errorPages) {
						if (epd.exception != null && peclass.equals(epd.exception)) {
							log("forward to " + epd.errorPage, t);
							((HttpServletResponse) response).sendRedirect(epd.errorPage);
							setErrorAttributes(request, -1, t.getMessage(), getServletName(),
									((HttpServletRequest) request).getRequestURI(), t, t.getClass());
							getRequestDispatcher(epd.errorPage).forward(request, response);
							return true;
						}
					}

			}
			return false;
		}

		protected void reset() {
			iterator = filters.iterator();
			nextFilter = filter;
		}

		protected void add(FilterAccessDescriptor fad) {
			if (fad.timeToReactivate > 0 && fad.timeToReactivate > System.currentTimeMillis())
				return;
			if (filters.contains(fad) == false)
				filters.add(fad);
		}

		protected void setServlet(HttpServlet servlet) {
			this.servlet = servlet;
		}

		protected void setServlet(ServletAccessDescr sad) {
			this.servlet = sad.instance;
			this.sad = sad;
		}
	}

	private final static boolean _DEBUG = false;
}