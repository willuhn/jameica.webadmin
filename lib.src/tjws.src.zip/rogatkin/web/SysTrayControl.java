/* tjws - SysTrayControl.java
 * Copyright (C) 1999-2007 Dmitriy Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  
 *  Visit http://tjws.sourceforge.net to get the latest infromation
 *  about Rogatkin's products.                                                        
 *  $Id: SysTrayControl.java,v 1.3 2007/01/17 10:22:24 rogatkin Exp $                
 *  Created on Jul 2, 2006
 *  @author Dmitriy
 */
package rogatkin.web;

import Acme.Serve.Serve;
import rogatkin.web.WebApp.ServiceController;
import java.util.Arrays;
import java.awt.AWTException;
import java.awt.Desktop;
import java.awt.Image;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import javax.swing.ImageIcon;

public class SysTrayControl implements ServiceController, ActionListener {

	private Serve s;

	private TrayIcon ti;

	private String contextPath;

	private String port = "" + Serve.DEF_PORT;

	public void attachServe(Serve serve, String contextPath) {
		s = serve;
		this.contextPath = contextPath;
		if (SystemTray.isSupported() == false)
			return;
		SystemTray st = SystemTray.getSystemTray();
		// TODO get text from localized resource
		PopupMenu popup = new PopupMenu();
		MenuItem mi;
		if (Desktop.isDesktopSupported()) {
			popup.add(mi = new MenuItem("Go " + contextPath));
			mi.addActionListener(this);
		}
		popup.add(mi = new MenuItem("stop"));
		mi.addActionListener(this);
		popup.add(mi = new MenuItem("exit"));
		mi.addActionListener(this);
		//java.net.URL u;
		ti = new TrayIcon(Toolkit.getDefaultToolkit().getImage(getClass().getClassLoader().getResource("rogatkin/resource/tjws.gif")), "TJWS control panel", popup);
		//javax.swing.JOptionPane.showMessageDialog(null, String.format("Created sys tray icon with image%s%n",u));
		ti.setImageAutoSize(true);

		try {
			st.add(ti);
		} catch (AWTException e) {

		}
	}

	public String[] massageSettings(String[] args) {
		boolean nohup = false;
		boolean nextPort = false;
		for (String arg : args)
			if ("-nohup".equals(arg)) {
				nohup = true;
			} else if ("-p".equals(arg))
				nextPort = true;
			else if (nextPort) {
				port = arg;
				nextPort = false;
			}

		if (SystemTray.isSupported()) {
			if (nohup == false) {
				args = Arrays.copyOf(args, args.length + 1);
				args[args.length - 1] = "-nohup";
			}
		} else {
			// remove '-nohup'

		}
		return args;
	}

	public void actionPerformed(ActionEvent event) {
		try {
			if ("stop".equals(event.getActionCommand())) {
				ti.displayMessage("TJWS", "Server stopped", TrayIcon.MessageType.INFO);
				s.stop();
			} else if ("exit".equals(event.getActionCommand())) {
				s.stop();
				System.exit(0);
			} else if (event.getActionCommand().startsWith("Go")) {
				//javax.swing.JOptionPane.showMessageDialog(null, String.format("http://localhost:%s/%s", port, contextPath));
				ti.displayMessage("TJWS", "Going to "+contextPath, TrayIcon.MessageType.INFO);
				Desktop desktop = Desktop.getDesktop();
				desktop.browse(new URI(String.format("http://localhost:%s/%s", port, contextPath)));
			} //else
				//javax.swing.JOptionPane.showMessageDialog(null, "Command "+event.getActionCommand());
		} catch (URISyntaxException e) {
			//e.printStackTrace();
		} catch (IOException e) {
			//e.printStackTrace();
		}
	}

}
