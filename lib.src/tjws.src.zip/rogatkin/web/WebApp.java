/* tjws - WebApp.java
 * Copyright (C) 1999-2007 Dmitriy Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  
 *  Visit http://tjws.sourceforge.net to get the latest infromation
 *  about Rogatkin's products.                                                        
 *  $Id: WebApp.java,v 1.9 2006/12/31 18:20:19 rogatkin Exp $                
 *  Created on Jun 12, 2006
 *  @author dmitriy
 */
package rogatkin.web;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;

import Acme.Utils;
import Acme.Serve.Serve;

public class WebApp extends Serve {

	public static final String RUN_DESCRIPTOR = "rundescriptor";

	/**
	 * @param args,
	 *            1st specifies .war file location others can match standard If no parameters specifies it considered as all in one and takes run descriptor
	 *            from /app/rundescriptor
	 *            <p>
	 *            rundescriptor file has multiple lines, 1st define command line argument<br>
	 *            following define names of .wars in /app/
	 */
	public static void main(String[] args) {
		File deployDir = getDeployDirectory("tjws-web-apps");
		if (deployDir == null) {
			System.err.println("Can't create deploy directory");
			System.exit(1);
		}
		deployDir.deleteOnExit();
		System.setProperty("tjws.webappdir", deployDir.getPath());
		ServiceController ctrl = null;
		try {
			ctrl = (ServiceController) Class.forName("rogatkin.web.SysTrayControl").newInstance();
		} catch (Exception ex) {
			// ex.printStackTrace();
		}
		if (args.length > 0) {
			System.out.printf("Launching %s...%n", args[0]);
			File warFile = new File(args[0]);
			try {
				copyWar(warFile, deployDir);
			} catch (IOException ioe) {
				System.err.printf("Can't copy war %s file to the deployment directory %s exception %s%n", warFile,
						deployDir, ioe);
				System.exit(2);
			}
			String[] newArgs = new String[args.length - 1];
			System.arraycopy(args, 1, newArgs, 0, newArgs.length);
			if (ctrl != null) {
				newArgs = ctrl.massageSettings(newArgs);
				ctrl.attachServe(Serve.serve, warFile.getName().substring(0, warFile.getName().length() - 4));
			}
			Serve.main(newArgs);
		} else {
			BufferedReader br = null;
			try {
				br = new BufferedReader(new InputStreamReader(Thread.currentThread().getContextClassLoader()
						.getResourceAsStream(RUN_DESCRIPTOR), "utf-8"));
			} catch (NullPointerException npe) {
				System.err.printf("Invalid jar format, no %s descriptor%n", RUN_DESCRIPTOR);
				System.exit(-2);
				return;
			} catch (UnsupportedEncodingException e) {
				System.err.printf("Unexpectable %s%n", e);
				System.exit(-3);
				return;
			}
			URL warUrl = null;
			try {
				// read clp
				String parameters = br.readLine();
				// can be loop if more than one war
				String warName;
				warUrl = Thread.currentThread().getContextClassLoader().getResource(warName = br.readLine());
				copyWar(warUrl, deployDir);
				if (ctrl != null) {
					ctrl.attachServe(Serve.serve, warName.substring(0, warName.length() - 4));
					Serve.main(ctrl.massageSettings(Utils.splitStr(parameters, "\"")));
				} else
					Serve.main(Utils.splitStr(parameters, "\""));
			} catch (IOException e) {
				System.err.printf("Can't copy war %s file to the deployment directory %s exception %s%n", warUrl,
						deployDir, e);
				System.exit(2);
			}
		}
	}

	public static File getDeployDirectory(String key) {
		String dirName = System.getProperty("java.io.tmpdir");
		if (dirName == null) {
			dirName = System.getProperty("user.home");
			if (dirName == null)
				dirName = ".";
		}
		File result = new File(dirName, key);
		try {
			result = result.getCanonicalFile();
			result.mkdirs(); // no check because can exist
			return result;
		} catch (IOException e) {
			System.err.printf("Can't create a deployment directory: %s %s%n", e, result);
		}
		return null;
	}

	public static void copyWar(File sourceWar, File deploymentDir) throws IOException {
		File targetWar = new File(deploymentDir, sourceWar.getName());
		if (targetWar.exists() && targetWar.lastModified() >= sourceWar.lastModified())
			return;
		OutputStream os = null;
		InputStream is = null;
		try {
			Utils.copyStream(is = new FileInputStream(sourceWar), os = new FileOutputStream(targetWar), -1);
		} finally {
			try {
				os.close();
			} catch (Exception e) {
			}
			try {
				is.close();
			} catch (Exception e) {
			}
		}
		targetWar.setLastModified(sourceWar.lastModified());
	}

	public static void copyWar(URL sourceWar, File deploymentDir) throws IOException {
		File targetWar = new File(deploymentDir, new File(sourceWar.getFile()).getName());
		URLConnection uc = sourceWar.openConnection();
		if (targetWar.exists() && targetWar.lastModified() >= uc.getLastModified())
			return;
		OutputStream os = null;
		InputStream is = null;
		try {
			Utils.copyStream(is = uc.getInputStream(), os = new FileOutputStream(targetWar), -1);
		} finally {
			try {
				os.close();
			} catch (Exception e) {
			}
			try {
				is.close();
			} catch (Exception e) {
			}
		}
		targetWar.setLastModified(uc.getLastModified());
	}

	public static interface ServiceController {
		void attachServe(Serve serv, String contextPath);

		String[] massageSettings(String[] args);
	}
}
