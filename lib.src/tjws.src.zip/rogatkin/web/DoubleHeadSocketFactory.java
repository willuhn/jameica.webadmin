/* tjws - DoubleHeadSocketFactory.java
 * Copyright (C) 1999-2007 Dmitriy Rogatkin.  All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 *  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR
 *  ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 *  DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 *  SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 *  OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 *  
 *  Visit http://tjws.sourceforge.net to get the latest infromation
 *  about Rogatkin's products.                                                        
 *  $Id: DoubleHeadSocketFactory.java,v 1.2 2006/12/31 18:20:19 rogatkin Exp $                
 *  Created on Feb 8, 2006
 *  @author dmitriy
 */
package rogatkin.web;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import Acme.Serve.SSLServerSocketFactory;
import Acme.Serve.Serve;
import Acme.Serve.Serve.SocketFactory;

public class DoubleHeadSocketFactory extends SSLServerSocketFactory implements SocketFactory {
	public ServerSocket createSocket(Map arguments) throws IOException {
		int port = arguments.get(Serve.ARG_PORT) != null ? ((Integer) arguments.get(Serve.ARG_PORT)).intValue()
				: Serve.DEF_PORT;
		int bl = 50;
		try {
			// TODO: consider conversion at getting the argument
			bl = Integer.parseInt((String) arguments.get(ARG_BACKLOG));
			if (bl < 2)
				bl = 2;
		} catch (Exception e) {
		}
		InetAddress ia = null;
		if (arguments.get(Serve.ARG_BINDADDRESS) != null)
			try {
				ia = InetAddress.getByName((String) arguments.get(Serve.ARG_BINDADDRESS));
			} catch (Exception e) {
			}
		Map argumentsSSL = new HashMap();
		argumentsSSL.putAll(arguments);
		
		argumentsSSL.put(ARG_PORT, Integer.parseInt((String) arguments.get("ssl-port")));
		argumentsSSL.put(ARG_BACKLOG, arguments.get("ssl-backlog"));
		return new TwoHeadServerSocket(new ServerSocket(port, bl, ia), super.createSocket(argumentsSSL));
	}

	public static class TwoHeadServerSocket extends ServerSocket {
		protected BlockingQueue<Socket> requestQueue; // ArrayBlockingQueue

		protected ServerSocket socket1, socket2;

		public TwoHeadServerSocket(ServerSocket socket1, ServerSocket socket2) throws IOException {
			requestQueue = new LinkedBlockingQueue<Socket>(1000); // ?? backlog
			if (socket1 != null) {
				new Thread(new AcceptQueuer(socket1), "Accept processor 1").start();
				this.socket1 = socket1;
			}
			if (socket2 != null) {
				new Thread(new AcceptQueuer(socket2), "Accept processor 2").start();
				this.socket2 = socket2;
			}
		}

		public Socket accept() throws IOException {
			Socket result;
			for (;;) {
				try {
					result = requestQueue.poll(1000L, TimeUnit.SECONDS);
					if (result != null)
						return result;
				} catch (InterruptedException e) {
					return null;
				}
			}
		}

		public void close() throws IOException {
			IOException ioe = null;
			try {
				socket1.close();
			} catch (IOException ioe1) {
				ioe = ioe1;
			}
			socket2.close();
			if (ioe != null)
				throw ioe;
		}
		
		public String toString() {
			return ""+socket1+"/"+socket2;
		}

		class AcceptQueuer implements Runnable {
			ServerSocket socket;

			AcceptQueuer(ServerSocket socket) {
				this.socket = socket;
			}

			public void run() {
				for (;;)
					try {
						requestQueue.put(socket.accept());
					} catch (InterruptedException e) {
						return;
					} catch (IOException e) {
					}
			}
		}
	}
}